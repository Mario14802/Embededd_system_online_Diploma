/*
 * registars.h
 *
 * Created: 12/11/2022 8:49:33 PM
 *  Author: MARIO
 */ 

#ifndef REGISTARS_H_
#define REGISTARS_H_
 
                         //*******************************//
                                 //DIO Registers 
                         //*******************************//	 
//PORTD Register//	
#define PIND            (*((volatile u8 *)  (0x30)))
#define DDRD			(*((volatile u8 *)  (0x31)))
#define PORTD			(*((volatile u8 *)  (0x32)))

//PORTC Register
#define PINC			(*((volatile u8 *)  (0x33)))
#define DDRC			(*((volatile u8 *)  (0x34)))
#define PORTC			(*((volatile u8 *)  (0x35)))

//PORTD Register
#define PINB			(*((volatile u8 *)  (0X36)))
#define DDRB			(*((volatile u8 *)  (0X37)))
#define PORTB			(*((volatile u8 *)  (0X38)))

//PORTA Register
#define PINA			(*((volatile u8 *) (0X39)))
#define DDRA			(*((volatile u8 *) (0X3A)))
#define PORTA			(*((volatile u8 *) (0X3B)))


//*******************************//
//TIMER0 Register
//*******************************//

#define  SREG  (*((volatile u8 *)(0x5F)))	  //i-bit
#define  TCCR0 (*((volatile u8 *)(0x53)))	  // WGM00/01  CS00/01/02
#define  TCNT0 (*((volatile u8 *)(0x52)))	  // counting register
#define  OCR0  (*((volatile u8 *)(0x5C)))	  // Comparing register
#define  TIMSK (*((volatile u8 *)(0x59)))	  // interrupt enable  for OVF,CTC
#define  TIFR  (*((volatile u8 *) (0x58)))	  //int flag
			 

//*******************************//
//INTERRUPT Register
//*******************************//
#define SREG   (*((volatile u8 *) (0x5F)))
#define GICR   (*((volatile u8 *) (0x5B)))
#define GIFR   (*((volatile u8 *) (0x5A)))
#define MCUCR  (*((volatile u8 *) (0x55)))
#define MCUCSR (*((volatile u8 *) (0x54)))


//*******************************//
//ADC Register
//*******************************// 
#define  ADMUX		(*((volatile u8 *) (0x27)))
#define  ADCSRA		(*((volatile u8 *) (0x26)))
#define  ADCH       (*((volatile u8 *) (0x25)))  
#define  ADCL       (*((volatile u8 *) (0x24))) 
#define  ADC        (*((volatile u16 *)(0x24)))
#define  SFIOR      (*((volatile u16 *)0x50))



//*******************************//
//UART Register
//*******************************//

#define  UCSRC	  (*((volatile u8 *)(0x40)))
#define  UBRRH	  (*((volatile u8 *)(0x40)))
#define  UCSRA	  (*((volatile u8 *)(0x2B)))
#define  UCSRB	  (*((volatile u8 *)(0x2A)))
#define  UBRRL	  (*((volatile u8 *)(0x29)))
#define  UDR	  (*((volatile u8 *)(0x2C)))


//*******************************//
//SPI Register
//*******************************//
#define  SPDR    (*((volatile u8 *) (0x2F)))
#define  SPSR    (*((volatile u8 *) (0x2E)))
#define  SPCR    (*((volatile u8 *) (0x2D)))


//*******************************//
// I2C Register
//*******************************//

#define TWBR    (*(volatile u8*)(0x20))
#define TWSR    (*(volatile u8*)(0x21))
#define TWAR    (*(volatile u8*)(0x22))
#define TWDR    (*(volatile u8*)(0x23))
#define TWCR    (*(volatile u8*)(0x56))


#endif /* REGISTARS_H_ */