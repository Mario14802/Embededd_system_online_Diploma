/*
 * UART_LESSON8_INT.c
 *
 * Created: 9/28/2023 6:05:23 PM
 * Author : MARIO
 */ 

#include "MCAL/GPIO/DIO.h"
#include "HAL/LCD/LCD.h"
#include "MCAL/UART/UART.h"
#include <stdint.h>



int main(void)
{
	USART_Init();
	 u8 str[8];
	 while(1)
	 {
	 USART_SendString("MARIO");
	 
	 USART_ReceiveString(str);
	 }
	 
	 return 0; 
}

