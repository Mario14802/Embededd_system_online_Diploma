/*
 * Unit6_int.c
 *
 * Created: 8/18/2023 2:07:00 PM
 * Author : MARIO
 */ 

#include <avr/io.h>
#include <stdint.h> 
#include <avr/interrupt.h> // For ISR
#include <util/delay.h> //for delay

//global interrupt
#define SREG    (*((volatile uint8_t*)(0x5F)))

//Interrupt
#define MCUCR    (*((volatile uint8_t*)(0x55)))
#define MCUCSR   (*((volatile uint8_t*)(0x54)))
#define GIFR     (*((volatile uint8_t*)(0x5A)))
#define GICR     (*((volatile uint8_t*)(0x5B)))
#define ISC00 0
#define ISC00 1


//GPIOA
#define PORTA   (*((volatile uint8_t*)(0x3B)))
#define DDRA    (*((volatile uint8_t*)(0x3A)))
#define PINA    (*((volatile uint8_t*)(0x39)))

//GPIOD for led 
#define PORTD   (*((volatile uint8_t*)(0x32)))
#define DDRD    (*((volatile uint8_t*)(0x31)))
#define PIND    (*((volatile uint8_t*)(0x30)))





void Ex_interrupt_init()
{
	//start global interrupt
	SREG |=(1<<7);	
	
   	//ENABEL INT0 
    GICR |=(1<<6);
	
	  // Set interrupt type for INT0 to any logical change
	  MCUCR |= (1 << ISC00);
	  MCUCR &= ~(1 << ISC01);
	
}
void GPIO_init()
{
	//make direction input for button pin0 by clearing bit
	DDRD &= ~(1 << 2);
	//make direction output for LED pin1 by setting bit
	DDRA  |= (1<<1);
	
}



int main(void)
{
	
	
Ex_interrupt_init();
GPIO_init();
    
    while (1);
    
}

ISR(INT0_vect)
{
	 PORTA |= (1 << 1); // Turn on the LED
	 _delay_ms(500);
	 PORTA &= ~(1 << 1); // Turn off the LED
	
}