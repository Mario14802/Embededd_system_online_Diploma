#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// Define GPIO for button pin 0
#define GPIO_BASE 0x40010800
#define GPIOx_CRL (*((volatile uint32_t*)(GPIO_BASE)))

// Define GPIO for LED at pin13
#define GPIOx_CRH (*((volatile uint32_t*)(GPIO_BASE + 0x04)))
#define GPIOx_ODR (*((volatile uint32_t*)(GPIO_BASE+ 0x0C)))
#define GPIOA13 (1UL<<13)

// Define interrupt controller found in Cortex-M
#define NVIC_ISER0 (*((volatile uint32_t*)(0xE000E100)))

// Define mask register
#define EXTI_IMR (*((volatile uint32_t*)(0x40010400 + 0x00)))

// Define rising edge
#define EXTI_RTSR (*((volatile uint32_t*)(0x40010400 + 0x08)))

// Define pending
#define EXTI_PR (*((volatile uint32_t*)(0x40010400 + 0x14)))

// Define AFIO
#define AFIO_EXTICR1 (*((volatile uint32_t*)(0x40010000 + 0x08)))

// Define RCC
#define RCC_APB2ENR (*((volatile uint32_t*)(0x40021000 + 0x18)))
#define RCC_IOPAEN (1 << 2)

void GPIOinit()
{
    // Pin0 BUTTON floating input
    GPIOx_CRL |= (1 << 2);

    // Pin13 init output
    GPIOx_CRH &= 0xFF0FFFFF;
    GPIOx_CRH |= 0x00200000;
}

void clockInit()
{
    // Enable clock for GPIOA
    RCC_APB2ENR |= RCC_IOPAEN;
}

int main(void)
{
    clockInit();
    GPIOinit();

    // Select PORTA for EXTI0
    AFIO_EXTICR1 = 0x0000;

    // Enable mask for EXTI0
    EXTI_IMR |= (1 << 0);

    // Enable rising edge for EXTI0
    EXTI_RTSR |= (1 << 0);

    // Enable NVIC (EXTI0)
    NVIC_ISER0 |= (1 << 6);

    while (1)
    {
        // Your main program logic here
    }
}

void EXTI0_IRQHandler(void)
{
    // Toggle LED
    GPIOx_ODR ^= (1 << 13);

    // Clear EXTI0 pending request
    EXTI_PR |= (1 << 0);
}
