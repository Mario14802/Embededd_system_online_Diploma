//Learn-in-depth
//Prepared By Mario Atef Nasr




#include <stdint.h>

extern int main (void);



void Reset_Handler(void);
void Default_handler(){
	Reset_Handler();
}
void NMI_Handler(void)__attribute__((weak, alias ("Default_handler")));;
void H_fault_Handler(void)__attribute__((weak, alias ("Default_handler")));;
void MM_Fault_Handler(void)__attribute__((weak, alias ("Default_handler")));;
void bus_fault_Handler(void)__attribute__((weak, alias ("Default_handler")));;

extern unsigned int _stack_top ;
uint32_t vectors[] __attribute__((section(".vectors"))) ={
(uint32_t) &_stack_top,
(uint32_t) &Reset_Handler,
(uint32_t) &NMI_Handler,
(uint32_t) &H_fault_Handler,
(uint32_t) &MM_Fault_Handler,
(uint32_t) &bus_fault_Handler,

};

extern unsigned int _E_text ;
extern unsigned int _S_DATA ;
extern unsigned int _E_DATA ;
extern unsigned int _S_bss ;
extern unsigned int _E_bss ;

void Reset_Handler (void)
{
	int i ;
	unsigned int DATA_SIZE = ((unsigned char*) &_E_DATA) - ((unsigned char*) &_S_DATA);
	unsigned char* Psrc = (unsigned char*) &_E_text;
	unsigned char* Pdst = (unsigned char*) &_S_DATA;

	for(i=0;i < DATA_SIZE ; i++ ){
	*((unsigned char* )Pdst++)= *((unsigned char* )Psrc++) ;
	}

	unsigned int bss_SIZE = ((unsigned char*) &_E_bss) - ((unsigned char*) &_S_bss);
	
	 Pdst = (unsigned char*) &_S_bss;

	for(i=0;i<bss_SIZE;i++){
	*((unsigned char* )Pdst++)= (unsigned char)0 ;
	}

main();

}