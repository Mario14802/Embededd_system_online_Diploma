#ifndef _MAIN_ALG_H_
#define _MAIN_ALG_H_


#include "AlarmMonitor.h"
#include "driver.h"
#include "pressure_sensor_driver.h"


#define threshold 20
#define nCount 600000

extern volatile unsigned int Pval;


void app();



#endif /*_MAIN_ALG_H_*/