#include <stdint.h>
#include <stdio.h>

#include "driver.h"
#include "Main_alg.h"
#include "pressure_sensor_driver.h"
#include "AlarmMonitor.h"



int main() {
    GPIO_INITIALIZATION();
   
    

    while (1) {
        
           app();

        }




    return 0;
}