#include "pressure_sensor_driver.h"


volatile unsigned  int Pval;

int set_P_value()
{
	Pval=getPressureVal();
	return Pval;

}