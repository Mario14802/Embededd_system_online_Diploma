
#ifndef _ALARM_MONITOR_H_
#define _ALARM_MONITOR_H_

#include "driver.h"



// Function to start the alarm
void start_alarm();

// Function to stop the alarm
void stop_alarm();
   

#endif/*_ALARM_MONITOR_H_*/