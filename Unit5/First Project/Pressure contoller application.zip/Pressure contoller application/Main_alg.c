#include "Main_alg.h"



void app(){

        if (Pval > threshold) {
        start_alarm();
        }
        else {
           stop_alarm();
        }

        Delay(nCount);

    }
