
#include "AlarmMonitor.h"




// Function to start the alarm
void start_alarm() {
    int i = 1;
    Set_Alarm_actuator(i);
}

// Function to stop the alarm
void stop_alarm() {
    int i = 0;
    Set_Alarm_actuator(i);
}
