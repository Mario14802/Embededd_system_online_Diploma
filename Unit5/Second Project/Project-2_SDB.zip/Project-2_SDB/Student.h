#ifndef _STUDENT_H_
#define _STUDENT_H_
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include "conio.h"
#include "string.h"
#include <stdbool.h>

#define MAX_STUDENTS 55
#define MAX_LINE_LENGTH 256

struct SDate
{
	char Fname[50];
	char Lname[50];
	int id;
	float GPA;
	int cid[10];
}Student_Database[MAX_STUDENTS];



void add_Student_File();
void add_Student_manually();
void find_Student_withID();
void find_Student_withFname();
void find_Student_RegInCourse();
void count_Students();
void delete_Student();
void update_Students();
bool isDuplicateID(int id);

#endif /*_STUDENT_H_*/