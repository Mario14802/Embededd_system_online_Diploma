#include "Student.h"
int numStudents = 0;



bool isDuplicateID(int id) {
    FILE* file = fopen("student.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return false;
    }

    int existingID;
    while (fscanf(file, "%*s %*s %d", &existingID) == 1) { //%*S means to ignoare string 
        if (existingID == id) {
            fclose(file);
            return true;
        }
    }

    fclose(file);
    return false;
}

void add_Student_File() {
    FILE* file = fopen("students.txt", "r");
    if (file == NULL) {
        printf("Failed to open the file.\n");
        return;
    }


    while (fscanf(file, "%s %s %d %f", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname, &Student_Database[numStudents].id, &Student_Database[numStudents].GPA) == 4) {
        for (int i = 0; i < 10; i++) {
            if (fscanf(file, "%d", &Student_Database[numStudents].cid[i]) != 1 || i >= 9)
                break;
        }

        numStudents++;

        if (numStudents >= MAX_STUDENTS) {
            printf("Maximum number of students reached.\n");
            break;
        }
    }

    fclose(file);

    printf("Added %d students to the database.\n", numStudents + 1);
}

void add_Student_manually() {
    int i;
    int id;

    printf("Enter the id:\n");
    scanf("%d", &id);

    if (isDuplicateID(id)) {
        printf("Error: Student with the same ID already exists.\n");
        return;
    }

    FILE* file = fopen("student.txt", "a");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return;
    }

    printf("Enter the first name:\n");
    scanf("%s", Student_Database[numStudents].Fname);

    printf("Enter the last name:\n");
    scanf("%s", Student_Database[numStudents].Lname);

    Student_Database[numStudents].id = id;

    printf("Enter the GPA:\n");
    scanf("%f", &Student_Database[numStudents].GPA);

    printf("Enter the course id:\n");
    for (i = 0; i < 3; i++)
        scanf("%d", &Student_Database[numStudents].cid[i]);

    if (numStudents >= MAX_STUDENTS) {
        printf("Maximum number of students reached.\n");
        fclose(file);
        return;
    }

    fprintf(file, "%s %s %d %f", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname, Student_Database[numStudents].id, Student_Database[numStudents].GPA);
    for (i = 0; i < 3; i++)
        fprintf(file, " %d", Student_Database[numStudents].cid[i]);
    fprintf(file, "\n");

    fclose(file);
    numStudents++;

    printf("Student added successfully.\n");
}

void find_Student_withID()
{
    int studentId;
    printf("Enter the student ID: ");
    scanf("%d", &studentId);

    FILE* file = fopen("student_data.txt", "r");
    if (file == NULL)
    {
        printf("Failed to open the file.\n");
        return;
    }

    int found = 0;
    char line[MAX_LINE_LENGTH];

    while (fgets(line, sizeof(line), file) != NULL)
    {
        sscanf(line, "%s %s %d %f", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname,
            &Student_Database[numStudents].id, &Student_Database[numStudents].GPA);

        if (Student_Database[numStudents].id == studentId)
        {
            found = 1;
            printf("Student found:\n");
            printf("Name: %s %s\n", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname);
            printf("ID: %d\n", Student_Database[numStudents].id);
            printf("GPA: %.2f\n", Student_Database[numStudents].GPA);
            printf("Course IDs: ");
            for (int j = 0; j < 3; j++)
            {
                printf("%d ", Student_Database[numStudents].cid[j]);
            }
            printf("\n");
            break;
        }
    }

    fclose(file);

    if (!found)
    {
        printf("No student found with the given ID.\n");
    }
}

void find_Student_withFname() {
    char fname[50];
    printf("Enter the first name to search: ");
    scanf("%s", fname);

    FILE* file = fopen("student.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return;
    }

    int found = 0;
    

    while (fscanf(file, "%s %s %d %f", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname, &Student_Database[numStudents].id, &Student_Database[numStudents].GPA) == 4) {
        for (int i = 0; i < 3; i++) {
            fscanf(file, "%d", &Student_Database[numStudents].cid[i]);
        }

        if (strcmp(Student_Database[numStudents].Fname, fname) == 0) {
            printf("Student found:\n");
            printf("Name: %s %s\n", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname);
            printf("ID: %d\n", Student_Database[numStudents].id);
            printf("GPA: %.2f\n", Student_Database[numStudents].GPA);
            printf("Course IDs: ");
            for (int i = 0; i < 3; i++) {
                printf("%d ", Student_Database[numStudents].cid[i]);
            }
            printf("\n");

            found = 1;
        }
    }

    fclose(file);

    if (!found) {
        printf("No student found with the given first name.\n");
    }
}

void find_Student_RegInCourse() {
    int courseId;  
    int i = 0;
    printf("Enter the course IDs to search :\n");
    scanf("%d", &courseId);  
  

    FILE* file = fopen("student.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return;
    }

    int found = 0;
    int numStudents = 0;  // Initialize the variable to keep track of the number of students

    while (fscanf(file, "%s %s %d %f", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname, &Student_Database[numStudents].id, &Student_Database[numStudents].GPA) == 4) {
        for (i = 0; i < 3; i++) {
            fscanf(file, "%d", &Student_Database[numStudents].cid[i]);
        }

        for (i = 0; i < 3; i++) {
            // Compare each course ID entered with the student's course IDs
            if (Student_Database[numStudents].cid[i] == courseId) {
                if (!found) {
                    printf("Students registered in course(s):\n");
                }
                printf("Name: %s %s \n", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname);
                printf("id: %d\n", Student_Database[numStudents].id);
                found = 1;
                break;  // Once a match is found, no need to continue checking the remaining courses
            }
        }
        numStudents++;  // Increment the number of students
    }

    fclose(file);

    if (!found) {
        printf("No students found registered in the given course ID(s).\n");
    }
}

void count_Students() {
    FILE* file = fopen("student.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return;
    }

    int count = 0;
    char temp[100];

    while (fgets(temp, sizeof(temp), file) != NULL) {
        count++;
    }

    fclose(file);

    printf("Number of students in the database: %d\n", count);
}

void delete_Student() {
    int studentId;
    printf("Enter the student ID to delete: ");
    scanf("%d", &studentId);

    FILE* file = fopen("student.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return;
    }

    FILE* tempFile = fopen("temp.txt", "w");
    if (tempFile == NULL) {
        printf("Error creating temporary file.\n");
        fclose(file);
        return;
    }

    int found = 0;
    

    while (fscanf(file, "%s %s %d %f", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname, &Student_Database[numStudents].id, &Student_Database[numStudents].GPA) == 4) {
        for (int i = 0; i < 3; i++) {
            fscanf(file, "%d", &Student_Database[numStudents].cid[i]);
        }

        if (Student_Database[numStudents].id == studentId) {
            found = 1;
        }
        else {
            fprintf(tempFile, "%s %s %d %.2f", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname, Student_Database[numStudents].id, Student_Database[numStudents].GPA);
            for (int i = 0; i < 3; i++) {
                fprintf(tempFile, " %d", Student_Database[numStudents].cid[i]);
            }
            fprintf(tempFile, "\n");
        }
    }

    fclose(file);
    fclose(tempFile);

    if (found) {
        remove("student.txt");
        rename("temp.txt", "student.txt");
        printf("Student with ID %d deleted from the database.\n", studentId);
    }
    else {
        remove("temp.txt");
        printf("No student found with the given ID.\n");
    }
}

void update_Students() {
    int studentId;
    printf("Enter the student ID to update: ");
    scanf("%d", &studentId);

    FILE* file = fopen("student.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return;
    }

    FILE* tempFile = fopen("temp.txt", "w");
    if (tempFile == NULL) {
        printf("Error creating temporary file.\n");
        fclose(file);
        return;
    }

    int found = 0;
   

    while (fscanf(file, "%s %s %d %f",Student_Database[numStudents].Fname,Student_Database[numStudents].Lname, &Student_Database[numStudents].id, &Student_Database[numStudents].GPA) == 4) {
        for (int i = 0; i < 3; i++) {
            fscanf(file, "%d", &Student_Database[numStudents].cid[i]);
        }

        if (Student_Database[numStudents].id == studentId) {
            found = 1;
            char newFname[50], newLname[50];
            float newGPA;

            printf("Enter the new first name: ");
            scanf("%s", newFname);
            printf("Enter the new last name: ");
            scanf("%s", newLname);
            printf("Enter the new GPA: ");
            scanf("%f", &newGPA);

            strcpy(Student_Database[numStudents].Fname, newFname);
            strcpy(Student_Database[numStudents].Lname, newLname);
            Student_Database[numStudents].GPA = newGPA;
        }

        fprintf(tempFile, "%s %s %d %.2f", Student_Database[numStudents].Fname, Student_Database[numStudents].Lname, Student_Database[numStudents].id, Student_Database[numStudents].GPA);
        for (int i = 0; i < 3; i++) {
            fprintf(tempFile, " %d", Student_Database[numStudents].cid[i]);
        }
        fprintf(tempFile, "\n");
    }

    fclose(file);
    fclose(tempFile);

    if (found) {
        remove("student.txt");
        rename("temp.txt", "student.txt");
        printf("Student with ID %d updated.\n", studentId);
    }
    else {
        remove("temp.txt");
        printf("No student found with the given ID.\n");
    }
}

