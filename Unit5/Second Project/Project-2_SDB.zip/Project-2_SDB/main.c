#include "Student.h"


int main() {
    int choice;
    do {
        printf("\n--- Menu ---\n");
        printf("1. Add students from file\n");
        printf("2. Add student manually\n");
        printf("3. Find student by ID\n");
        printf("4. Find student by first name\n");
        printf("5. Find students registered in a course\n");
        printf("6. Count number of students\n");
        printf("7. Delete a student\n");
        printf("8. Update student information\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
        case 1:
            add_Student_File();
            break;
        case 2:
            add_Student_manually();
            break;
        case 3:
            find_Student_withID();
            break;
        case 4:
            find_Student_withFname();
            break;
        case 5:
            find_Student_RegInCourse();
            break;
        case 6:
            count_Students();
            break;
        case 7:
            delete_Student();
            break;
        case 8:
            update_Students();
            break;
        default:
            printf("Invalid choice! Please enter a valid option.\n");
            break;
        }
    } while (choice != 9);

    return 0;
}

